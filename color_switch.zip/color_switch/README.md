# color_switch

A sample Flutter project for assignment

## Getting Started

1. Open color_switch folder in Visual Studio Code. 
2. open new Terminal through Visual Studio Code.
3. Run "flutter run" command to build and deploy the app to Android/iOS simulator

